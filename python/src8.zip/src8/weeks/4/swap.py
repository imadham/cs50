# Swaps two integers


def main():
    x = 1
    y = 2

    print(f"x is {x}, y is {y}")
    x, y = y, x
    print(f"x is {x}, y is {y}")


if __name__ == "__main__":
    main()
