# Prints string char by char

from cs50 import get_string

s = get_string()
if s:
    for c in s:
        print(c)
