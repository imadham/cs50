# Prints four question marks using a loop

for i in range(4):
    print("?", end="")
print()
