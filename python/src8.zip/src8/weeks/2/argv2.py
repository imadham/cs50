# Printing characters in an array of strings

from sys import argv

for s in argv:
    for c in s:
        print(c)
    print()
