# Buggy example for help50

s = get_string("Name: ")
print(f"hello, {s}")
