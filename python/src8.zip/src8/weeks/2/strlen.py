# Determines the length of a string

from cs50 import get_string

s = get_string("Name: ")
print(len(s))
