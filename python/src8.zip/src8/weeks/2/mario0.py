# Prints four question marks

print("????")
