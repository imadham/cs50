# Prints string char by char, one per line

from cs50 import get_string

s = get_string("input: ")
print("output:");
for c in s:
    print(c)
