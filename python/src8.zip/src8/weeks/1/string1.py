# Demonstrates format

from cs50 import get_string

s = get_string("name: ")
print("hello, {}".format(s))
