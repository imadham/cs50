# Floating-point imprecision

print(f"{1/10:.55f}")
