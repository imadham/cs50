# Integer overflow

from time import sleep

# Iteratively double i
i = 1
while True:
    print(i)
    i *= 2
    sleep(1)
