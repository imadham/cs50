# Floating-point arithmetic

from cs50 import get_float

# Prompt user for x
x = get_float("x: ")

# Prompt user for y
y = get_float("y: ")

# Perform division for user
print(f"{x} divided by {y} is {x / y}")
