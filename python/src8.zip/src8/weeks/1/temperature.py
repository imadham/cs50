# Floating-point arithmetic

from cs50 import get_float

f = get_float("F: ")
c = 5 / 9 * (f - 32)
print(f"{c:.1f}")
