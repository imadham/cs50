# Says hello to someone

s = input()
print(f"hello, {s}")
